document.getElementById('startButton').addEventListener('click', function () {
    console.log('WeatherNow is ready to serve you!');
});